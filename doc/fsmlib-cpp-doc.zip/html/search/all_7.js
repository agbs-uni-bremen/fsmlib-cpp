var searchData=
[
  ['leaves',['leaves',['../class_tree.html#ac9ead9591cabcac716f030be1a49f0fd',1,'Tree']]]
];
