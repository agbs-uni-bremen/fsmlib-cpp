var searchData=
[
  ['parent',['parent',['../class_tree_node.html#a3e6b85c69f917dcadfe8f9affd4d4db6',1,'TreeNode']]],
  ['presentationlayer',['presentationLayer',['../class_trace.html#af81e7091d67f45deb9930c1005c34aa7',1,'Trace::presentationLayer()'],['../class_tree.html#a610429ba404dc1a13b08e686bbb110ef',1,'Tree::presentationLayer()']]]
];
