var searchData=
[
  ['remove',['remove',['../class_tree.html#a79b08979bfb5c6d9edfab0eee9879961',1,'Tree::remove()'],['../class_tree_node.html#a05ceb259978558d5a6da925426424791',1,'TreeNode::remove()']]],
  ['root',['root',['../class_tree.html#ab798e139df267d492b22473a4c3d7a40',1,'Tree']]]
];
