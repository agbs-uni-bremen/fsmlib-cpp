var searchData=
[
  ['hasedge',['hasEdge',['../class_tree_node.html#ac60ccdbac21b1f9f077349ea8b2c91c8',1,'TreeNode']]],
  ['hittingset',['HittingSet',['../class_hitting_set.html#a701630d1df487667931a76d2b4eefed9',1,'HittingSet']]]
];
