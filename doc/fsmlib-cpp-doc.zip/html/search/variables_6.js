var searchData=
[
  ['root',['root',['../class_tree.html#ab798e139df267d492b22473a4c3d7a40',1,'Tree']]]
];
