var searchData=
[
  ['deleted',['deleted',['../class_tree_node.html#ad9a16871aad7be316408a1f8a21731a2',1,'TreeNode']]]
];
